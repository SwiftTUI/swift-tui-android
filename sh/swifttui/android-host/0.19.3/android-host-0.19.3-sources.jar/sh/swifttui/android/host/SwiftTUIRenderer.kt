package sh.swifttui.android.host

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.util.Base64
import android.util.LruCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.max
import kotlin.math.roundToInt

// Per-host rendering surface. Holds the mutable bitmap cache and retained grid
// state, so it must be instantiated once per host view (via `remember`) rather
// than shared as a singleton — two hosts sharing one instance would corrupt
// each other's frames. Pure colour helpers live as file-level functions below.
class SwiftTUIRenderer internal constructor(
  private val onMissingImagePayload: (String) -> Unit
) {
  constructor() : this(onMissingImagePayload = {})

  private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    typeface = Typeface.MONOSPACE
  }
  private val backgroundPaint = Paint()
  private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
  private val mutedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    color = android.graphics.Color.rgb(151, 162, 178)
    typeface = Typeface.MONOSPACE
  }
  // Decoded image-attachment bitmaps, bounded so cycling through image-heavy
  // demos cannot leak for the process lifetime; evicted bitmaps are recycled.
  private val bitmapCache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount

    override fun entryRemoved(
      evicted: Boolean,
      key: String,
      oldValue: Bitmap,
      newValue: Bitmap?
    ) {
      if (oldValue != newValue && !oldValue.isRecycled) {
        oldValue.recycle()
      }
    }
  }

  // Retained grid surface. Cells are painted once and only the damaged rows are
  // repainted on subsequent frames, so a typing/cursor/animation update no
  // longer re-runs drawText for the whole grid.
  private var cacheBitmap: Bitmap? = null
  private var cacheCanvas: Canvas? = null
  private var cacheWidth = 0
  private var cacheHeight = 0
  private var lastRenderedSequence = -1L

  fun drawFrame(
    drawScope: DrawScope,
    frame: SwiftTUIFrame?,
    style: SwiftTUIAndroidStyle,
    lastError: String?
  ) {
    val terminalStyle = frame?.terminalStyle ?: SwiftTUITerminalStyle.Default
    drawScope.drawRect(terminalStyle.backgroundColor.toComposeColor())

    val textSize = style.cellHeightPx * 0.78f
    textPaint.textSize = textSize
    mutedPaint.textSize = textSize
    val baselineOffset =
      (style.cellHeightPx - textPaint.fontMetrics.bottom - textPaint.fontMetrics.top) / 2f

    if (frame == null) {
      drawScope.drawIntoCanvas { canvas ->
        canvas.nativeCanvas.drawText(
          lastError ?: "Starting SwiftTUI...",
          0f,
          baselineOffset,
          mutedPaint
        )
      }
      return
    }

    renderGridToCache(frame, terminalStyle, style, baselineOffset)

    drawScope.drawIntoCanvas { canvas ->
      cacheBitmap?.let { canvas.nativeCanvas.drawBitmap(it, 0f, 0f, null) }

      if (lastError != null) {
        canvas.nativeCanvas.drawText(
          lastError,
          0f,
          drawScope.size.height - style.cellHeightPx,
          mutedPaint
        )
      }
    }

    val focusColor = frame.terminalStyle.tintColor.toComposeColor()
    if (frame.focusPresentation.hasFocusedRegion) {
      drawScope.drawLine(
        color = focusColor,
        start = Offset(0f, drawScope.size.height - 1f),
        end = Offset(drawScope.size.width, drawScope.size.height - 1f),
        strokeWidth = 1f
      )
    }
  }

  private fun renderGridToCache(
    frame: SwiftTUIFrame,
    terminalStyle: SwiftTUITerminalStyle,
    style: SwiftTUIAndroidStyle,
    baselineOffset: Float
  ) {
    val gridWidthPx = max(1, (frame.gridWidth * style.cellWidthPx).roundToInt())
    val gridHeightPx = max(1, (frame.gridHeight * style.cellHeightPx).roundToInt())
    val resized = cacheBitmap == null || cacheWidth != gridWidthPx || cacheHeight != gridHeightPx
    if (resized) {
      cacheBitmap?.recycle()
      val bitmap = Bitmap.createBitmap(gridWidthPx, gridHeightPx, Bitmap.Config.ARGB_8888)
      cacheBitmap = bitmap
      cacheCanvas = Canvas(bitmap)
      cacheWidth = gridWidthPx
      cacheHeight = gridHeightPx
    }
    val canvas = cacheCanvas ?: return
    val backgroundArgb = terminalStyle.backgroundColor.toArgb()

    val plan = SwiftTUIDamagePlan.plan(
      frame = frame,
      previousSequence = lastRenderedSequence,
      sizeChanged = resized
    )

    if (plan.fullRepaint) {
      canvas.drawColor(backgroundArgb, PorterDuff.Mode.SRC)
      drawCells(canvas, frame.cells, terminalStyle, style, baselineOffset)
      drawImages(canvas, frame, style)
    } else {
      val damagedCells = ArrayList<SwiftTUICell>()
      val damagePath = Path()
      for (rect in SwiftTUIRasterClipGeometry.damage(plan)) {
        damagePath.addRect(pixelRect(rect, style), Path.Direction.CW)
      }
      if (!damagePath.isEmpty) {
        val saved = canvas.save()
        try {
          // One union clip preserves holes between damaged ranges. A selected
          // wide lead may cover clean columns that must not be composited twice.
          canvas.clipPath(damagePath)
          canvas.drawColor(backgroundArgb, PorterDuff.Mode.SRC)
          SwiftTUIDamagePlan.forEachDamagedCell(frame, plan, damagedCells::add)
          drawCells(canvas, damagedCells, terminalStyle, style, baselineOffset)
        } finally {
          canvas.restoreToCount(saved)
        }
      }
    }

    lastRenderedSequence = frame.consumedGeneration
  }

  private fun drawCells(
    canvas: Canvas,
    cells: List<SwiftTUICell>,
    terminalStyle: SwiftTUITerminalStyle,
    style: SwiftTUIAndroidStyle,
    baselineOffset: Float
  ) {
    cells.forEach { cell ->
      if (cell.isContinuation) {
        return@forEach
      }

      val rect = pixelRect(SwiftTUIRasterClipGeometry.cell(cell), style)
      val textStyle = cell.style
      val reverse = textStyle?.emphasis?.contains("reverse") == true
      val foreground = if (reverse) {
        textStyle?.backgroundColor ?: terminalStyle.backgroundColor
      } else {
        textStyle?.foregroundColor ?: terminalStyle.foregroundColor
      }
      val background = if (reverse) {
        textStyle?.foregroundColor ?: terminalStyle.foregroundColor
      } else {
        textStyle?.backgroundColor
      }

      if (background != null) {
        backgroundPaint.color = background.toArgb(textStyle?.opacity ?: 1.0)
        canvas.drawRect(rect, backgroundPaint)
      }

      if ((cell.character == " " || cell.character.isEmpty()) &&
        textStyle?.underlineStyle == null && textStyle?.strikethroughStyle == null
      ) {
        return@forEach
      }

      // Full paints and partial paints share the same ink ownership. Italic
      // overhang and decorations cannot leave pixels outside the declared span.
      val saved = canvas.save()
      try {
        canvas.clipRect(rect)
        if (cell.character != " " && cell.character.isNotEmpty()) {
          val foregroundArgb = foreground.toArgb(
            opacity = textStyle?.opacity ?: 1.0,
            faint = textStyle?.emphasis?.contains("faint") == true
          )
          // Box-drawing / block / braille glyphs are painted procedurally so
          // they tile between cells without gaps from the font.
          val codePoint = cell.character.codePointAt(0)
          val drawnProcedurally =
            cell.character.codePointCount(0, cell.character.length) == 1 &&
              SwiftTUIBoxDrawing.canRender(codePoint) &&
              SwiftTUIBoxDrawing.draw(canvas, codePoint, rect, foregroundArgb)

          if (!drawnProcedurally) {
            configureTextPaint(foregroundArgb = foregroundArgb, style = textStyle)
            canvas.drawText(
              cell.character,
              rect.left,
              rect.top + baselineOffset,
              textPaint
            )
          }
        }

        drawLineDecoration(
          canvas = canvas,
          rect = rect,
          style = textStyle?.underlineStyle,
          fallbackColor = foreground,
          opacity = textStyle?.opacity ?: 1.0,
          y = rect.bottom - 2f
        )
        drawLineDecoration(
          canvas = canvas,
          rect = rect,
          style = textStyle?.strikethroughStyle,
          fallbackColor = foreground,
          opacity = textStyle?.opacity ?: 1.0,
          y = rect.centerY()
        )
      } finally {
        canvas.restoreToCount(saved)
      }
    }
  }

  private fun drawImages(
    canvas: Canvas,
    frame: SwiftTUIFrame,
    style: SwiftTUIAndroidStyle
  ) {
    frame.imageAttachments.forEach { attachment ->
      val placement = SwiftTUIImagePlacement.forAttachment(attachment) ?: return@forEach
      val cacheKey = swiftTUIImageCacheKey(attachment)
      val bitmap = bitmapFor(attachment) ?: return@forEach
      if (bitmap.isRecycled) {
        bitmapCache.remove(cacheKey)
        return@forEach
      }
      val rect = pixelRect(placement.destination, style)
      // Alpha belongs to the placement, not the decoded image. The bitmap
      // remains cached under content identity while every replay applies the
      // current effective opacity.
      imagePaint.alpha = swiftTUIImageAlpha(attachment.opacity)
      val saved = canvas.save()
      try {
        canvas.clipRect(pixelRect(placement.clip, style))
        canvas.drawBitmap(bitmap, null, rect, imagePaint)
      } finally {
        canvas.restoreToCount(saved)
      }
    }
  }

  private fun configureTextPaint(
    foregroundArgb: Int,
    style: SwiftTUITextStyle?
  ) {
    textPaint.color = foregroundArgb
    textPaint.typeface = typeface(style?.emphasis.orEmpty())
    textPaint.isUnderlineText = false
    textPaint.isStrikeThruText = false
  }

  private fun drawLineDecoration(
    canvas: Canvas,
    rect: RectF,
    style: SwiftTUITextLineStyle?,
    fallbackColor: SwiftTUIColor,
    opacity: Double,
    y: Float
  ) {
    if (style == null) {
      return
    }

    linePaint.color = (style.color ?: fallbackColor).toArgb(opacity)
    linePaint.strokeWidth = if (style.pattern == "double") 2f else 1f
    canvas.drawLine(rect.left, y, rect.right, y, linePaint)
  }

  private fun pixelRect(
    rect: SwiftTUIRect,
    style: SwiftTUIAndroidStyle
  ): RectF =
    RectF(
      rect.x * style.cellWidthPx,
      rect.y * style.cellHeightPx,
      SwiftTUIRasterClipGeometry.pixelEnd(rect.x, rect.width, style.cellWidthPx),
      SwiftTUIRasterClipGeometry.pixelEnd(rect.y, rect.height, style.cellHeightPx)
    )

  private fun typeface(emphasis: Set<String>): Typeface {
    val typefaceStyle = when {
      emphasis.contains("bold") && emphasis.contains("italic") -> Typeface.BOLD_ITALIC
      emphasis.contains("bold") -> Typeface.BOLD
      emphasis.contains("italic") -> Typeface.ITALIC
      else -> Typeface.NORMAL
    }
    return Typeface.create(Typeface.MONOSPACE, typefaceStyle)
  }

  private fun bitmapFor(
    attachment: SwiftTUIImageAttachment
  ): Bitmap? {
    val cacheKey = swiftTUIImageCacheKey(attachment)
    return when (val resolution = SwiftTUIBitmapCachePolicy.resolve(
      key = cacheKey,
      cached = { bitmapCache.get(cacheKey) },
      payload = attachment.payloadBase64,
      decode = decode@ { payload ->
        val bytes = runCatching {
          Base64.decode(payload, Base64.DEFAULT)
        }.getOrNull() ?: return@decode null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (!SwiftTUIWireBudget.imageSize(bounds.outWidth, bounds.outHeight)) return@decode null
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
      },
      maxSize = bitmapCache::maxSize,
      sizeOf = Bitmap::getByteCount,
      put = bitmapCache::put
    )) {
      is SwiftTUIBitmapResolution.Drawable -> resolution.value
      SwiftTUIBitmapResolution.MissingPayload -> {
        onMissingImagePayload(attachment.id)
        null
      }
      SwiftTUIBitmapResolution.InvalidPayload -> null
    }
  }

}

internal fun normalizedSwiftTUIImageOpacity(opacity: Double): Double =
  if (opacity.isFinite()) opacity.coerceIn(0.0, 1.0) else 1.0

internal fun swiftTUIImageAlpha(opacity: Double): Int =
  (normalizedSwiftTUIImageOpacity(opacity) * 255.0).roundToInt()

internal fun swiftTUIImageCacheKey(
  attachment: SwiftTUIImageAttachment
): String = "${attachment.id}:${attachment.payloadByteCount ?: 0}"

fun SwiftTUIColor.toComposeColor(): Color = Color(toArgb())

fun SwiftTUIColor.toArgb(
  opacity: Double = 1.0,
  faint: Boolean = false
): Int {
  val trimmed = hex.removePrefix("#")
  val red = trimmed.component(0)
  val green = trimmed.component(1)
  val blue = trimmed.component(2)
  val alpha = if (trimmed.length >= 8) trimmed.component(3) else 255
  val adjustedAlpha = (alpha * opacity.coerceIn(0.0, 1.0) * if (faint) 0.6 else 1.0)
    .roundToInt()
    .coerceIn(0, 255)
  return android.graphics.Color.argb(adjustedAlpha, red, green, blue)
}

private fun String.component(
  index: Int
): Int {
  val start = index * 2
  if (length < start + 2) {
    return 0
  }
  return substring(start, start + 2).toIntOrNull(16) ?: 0
}
