package sh.swifttui.android.host

import org.json.JSONObject

internal sealed interface SwiftTUIFramePollResult {
  data object None : SwiftTUIFramePollResult
  data class Frame(
    val value: SwiftTUIFrame,
    /**
     * A requested payload may be re-encoded from the latest application frame,
     * so its application [SwiftTUIFrame.sequence] legitimately stays equal to
     * the frame currently published by host state. This signal bypasses only
     * that duplicate-sequence suppression.
     */
    val isImagePayloadRepair: Boolean,
    val isSessionReplacement: Boolean = false
  ) : SwiftTUIFramePollResult {
    fun shouldPublishOver(current: SwiftTUIFrame?): Boolean =
      isSessionReplacement || isImagePayloadRepair || value.sequence != current?.sequence
  }
  data class Error(val message: String) : SwiftTUIFramePollResult
}

/**
 * Owns the delivery-repair state for the Android size/copy poll seam.
 *
 * A rejected record schedules one keyframe request. The request stays
 * outstanding even when an older Swift host does not expose the resync
 * symbol, so the Kotlin host waits for an incidental full frame instead of
 * flooding the bridge on every poll. Image repair is independent: missing IDs
 * are coalesced into one sorted request and each remains outstanding until a
 * payload-bearing record for that exact ID arrives.
 */
internal class SwiftTUIFramePoller(
  private val session: SwiftTUIWebSurfaceSession,
  private val copyLatestFrame: (Long, ByteArray?, Int) -> Int,
  private val requestResync: (Long, ByteArray, Int) -> Int
) {
  internal val epoch: Long? get() = session.lastEpoch
  private var hasPresentedFrame = false
  private var keyframeRequestOutstanding = false
  private val queuedImagePayloadIds = linkedSetOf<String>()
  private val outstandingImagePayloadIds = mutableSetOf<String>()

  fun reset() {
    session.reset()
    hasPresentedFrame = false
    keyframeRequestOutstanding = false
    queuedImagePayloadIds.clear()
    outstandingImagePayloadIds.clear()
  }

  fun reportMissingImagePayloads(ids: Iterable<String>) {
    for (id in ids) {
      if (id.isNotEmpty() && SwiftTUIWireBudget.fitsUTF8(id, 1024) &&
        queuedImagePayloadIds.size + outstandingImagePayloadIds.size < SwiftTUIWireBudget.IMAGES &&
        id !in outstandingImagePayloadIds) {
        queuedImagePayloadIds.add(id)
      }
    }
  }

  fun poll(handle: Long): SwiftTUIFramePollResult {
    val needed = copyLatestFrame(handle, null, 0)
    if (needed <= 0) {
      dispatchPendingResync(handle)
      return SwiftTUIFramePollResult.None
    }
    if (needed > SwiftTUIWireBudget.RECORD_BYTES + 1) return refuseOversizedRecord(handle)

    var bytes = ByteArray(needed)
    var copied = copyLatestFrame(handle, bytes, bytes.size)
    if (copied > bytes.size) {
      if (copied > SwiftTUIWireBudget.RECORD_BYTES + 1) return refuseOversizedRecord(handle)
      // The record grew between the size query and the copy, so no bytes were
      // written. A delivery-coupled host never does this — its copy leg serves
      // exactly the bytes the size query measured — but an older native host
      // re-encodes a newer frame at copy time. Retry once at the larger
      // reported size instead of dropping the whole poll; correctness comes
      // from the host's candidate commit, this is only latency.
      bytes = ByteArray(copied)
      copied = copyLatestFrame(handle, bytes, bytes.size)
    }
    if (copied <= 0 || copied > bytes.size) {
      dispatchPendingResync(handle)
      return SwiftTUIFramePollResult.None
    }

    val previousEpoch = session.lastEpoch
    val decoded = runCatching {
      val payload = decodeStrictFrameUTF8(bytes, copied)
      require(!payload.startsWith("\u001EruntimeIssue:")) {
        "SwiftTUI host refused to encode the frame within its wire allocation budget."
      }
      require(SwiftTUIWebSurfaceSession.isWebSurfaceRecord(payload)) {
        "legacy SwiftTUI frame received; the app's swift-tui host library " +
          "predates the converged web-surface wire — update the swift-tui " +
          "dependency to match this AAR."
      }
      session.decodeValidatedUTF8(payload, copied)
    }

    val error = decoded.exceptionOrNull()
    if (error != null) {
      session.requestKeyframeRecovery()
      dispatchPendingResync(handle)
      return SwiftTUIFramePollResult.Error(error.message ?: error.toString())
    }

    val frame = decoded.getOrNull()
    if (frame == null) {
      dispatchPendingResync(handle)
      return SwiftTUIFramePollResult.None
    }

    val isSessionReplacement = hasPresentedFrame && previousEpoch != session.lastEpoch
    hasPresentedFrame = true
    if (isSessionReplacement) {
      queuedImagePayloadIds.clear()
      outstandingImagePayloadIds.clear()
    }
    var isImagePayloadRepair = false
    val presentedIds = frame.imageAttachments.mapTo(mutableSetOf()) { it.id }
    queuedImagePayloadIds.retainAll(presentedIds)
    outstandingImagePayloadIds.retainAll(presentedIds)
    for (attachment in frame.imageAttachments) {
      if (attachment.payloadBase64 != null) {
        if (
          attachment.id in queuedImagePayloadIds ||
          attachment.id in outstandingImagePayloadIds
        ) {
          isImagePayloadRepair = true
        }
        queuedImagePayloadIds.remove(attachment.id)
        outstandingImagePayloadIds.remove(attachment.id)
      }
    }

    if (session.pendingResyncScope == null) {
      keyframeRequestOutstanding = false
    }
    dispatchPendingResync(handle)
    return SwiftTUIFramePollResult.Frame(
      value = frame,
      isImagePayloadRepair = isImagePayloadRepair,
      isSessionReplacement = isSessionReplacement
    )
  }

  private fun dispatchPendingResync(handle: Long) {
    if (
      session.pendingResyncScope == SwiftTUIWebSurfaceSession.KEYFRAME_RESYNC_SCOPE &&
      !keyframeRequestOutstanding
    ) {
      val request = KEYFRAME_RESYNC_JSON.encodeToByteArray()
      // Mark outstanding regardless of the return value. A zero result is the
      // old-host fallback: wait for an incidental full frame.
      keyframeRequestOutstanding = true
      requestResync(handle, request, request.size)
    }

    if (queuedImagePayloadIds.isEmpty()) {
      return
    }
    val ids = queuedImagePayloadIds.sorted()
    queuedImagePayloadIds.clear()
    outstandingImagePayloadIds.addAll(ids)
    val json = ids.joinToString(
      separator = ",",
      prefix = """{"scope":"images","ids":[""",
      postfix = "]}"
    ) { id ->
      JSONObject.quote(id)
    }
    val request = json.encodeToByteArray()
    // As with keyframes, zero means an older host lacks the optional symbol.
    // Keeping the IDs outstanding prevents a 30 Hz request loop.
    requestResync(handle, request, request.size)
  }

  private fun refuseOversizedRecord(handle: Long): SwiftTUIFramePollResult {
    session.requestKeyframeRecovery()
    dispatchPendingResync(handle)
    return SwiftTUIFramePollResult.Error("SwiftTUI wire record exceeds the byte budget")
  }

  private companion object {
    const val KEYFRAME_RESYNC_JSON = """{"scope":"keyframe"}"""
  }
}

/** The platform decoder substitutes U+FFFD for every malformed UTF-8 sequence.
 * Its absence therefore proves the fast decode was lossless. Only a substituted
 * or literal U+FFFD needs the strict decoder to distinguish those cases; ordinary
 * ASCII and Unicode frames avoid its decoder/character-buffer allocations.
 * JSON is still materialized exactly once by the session after this admission.
 */
private fun decodeStrictFrameUTF8(bytes: ByteArray, count: Int): String {
  val text = bytes.decodeToString(0, count)
  return if ('\uFFFD' in text) bytes.decodeToString(0, count, throwOnInvalidSequence = true) else text
}
